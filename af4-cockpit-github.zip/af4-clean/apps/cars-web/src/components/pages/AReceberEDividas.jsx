import React, { useState, useMemo } from "react";
import { Plus, Trash2, Edit3, Check, X, MessageCircle } from "lucide-react";
import { T } from "../../lib/theme.js";
import { fmt, uid, todayISO } from "../../lib/format.js";
import { parseValorBR } from "../../lib/importExport.js";
import { confirm } from "../../lib/confirm.js";
import { toast } from "../../lib/toast.js";
import { whatsapp } from "../../lib/whatsapp.js";
import PageHeader from "../ui/PageHeader.jsx";
import Modal from "../ui/Modal.jsx";
import Field from "../ui/Field.jsx";

/**
 * Aba dedicada: A Receber (devedores) + Dívidas (a pagar).
 * Na hora de dar baixa, escolhe a conta de destino/origem e:
 *   - cria transação (receita/despesa) compensada;
 *   - ajusta saldo da conta;
 *   - marca o item como recebido/pago.
 */
export default function AReceberEDividas({
  devedores = [], setDevedores,
  dividas = [], setDividas,
  contas = [], setContas,
  transacoes = [], setTransacoes,
  categorias = [],
  hidden,
}) {
  const [form, setForm] = useState(null);        // {tipo, ...} novo/editar
  const [baixaForm, setBaixaForm] = useState(null); // baixa de um item

  const hoje = todayISO();
  const em3d = new Date();
  em3d.setDate(em3d.getDate() + 3);
  const em3dIso = em3d.toISOString().slice(0, 10);
  const em7d = new Date();
  em7d.setDate(em7d.getDate() + 7);
  const em7dIso = em7d.toISOString().slice(0, 10);
  // Último dia do mês corrente — para o bucket "Verde · No prazo"
  const fimMes = new Date();
  fimMes.setMonth(fimMes.getMonth() + 1, 0);
  const fimMesIso = fimMes.toISOString().slice(0, 10);

  /* ===== Helpers ===== */
  const diasParaVencer = (data) => {
    if (!data) return null;
    const d = new Date(data);
    const h = new Date(hoje);
    return Math.round((d - h) / 86400000);
  };

  const dueLabel = (data) => {
    if (!data) return { txt: "Sem data", cor: T.muted, status: "none" };
    const dias = diasParaVencer(data);
    if (dias < 0)  return { txt: `${data.slice(8,10)}/${data.slice(5,7)} · ${dias}d`, cor: T.red,   status: "over" };
    if (dias <= 3) return { txt: `${data.slice(8,10)}/${data.slice(5,7)} · ${dias === 0 ? "hoje" : `${dias}d`}`, cor: T.gold,  status: "warn" };
    if (dias <= 7) return { txt: `${data.slice(8,10)}/${data.slice(5,7)} · ${dias}d`, cor: T.green, status: "ok-near" };
    return { txt: `${data.slice(8,10)}/${data.slice(5,7)} · ${dias}d`, cor: T.muted, status: "ok" };
  };

  /* ===== Salvar novo/editar ===== */
  const save = () => {
    if (!form.nome?.trim()) { toast.error("Nome obrigatório."); return; }
    const valor = parseValorBR(form.valor);
    if (isNaN(valor) || valor <= 0) { toast.error("Valor inválido."); return; }

    const data = {
      ...form,
      valor,
    };

    // Edição → comportamento simples: atualiza só esta entrada
    if (form.id) {
      if (form.tipo === "receber") {
        setDevedores(devedores.map(d => d.id === form.id ? data : d));
      } else {
        setDividas(dividas.map(d => d.id === form.id ? data : d));
      }
      toast.success("Atualizado.");
      setForm(null);
      return;
    }

    // Criação nova: detecta se é parcelado (campo "parcela" no formato "1/N")
    // Se for, gera N entradas com vencimento mensal subsequente.
    const matchParc = (form.parcela || "").trim().match(/^(\d+)\s*\/\s*(\d+)$/);
    const totalParc = matchParc ? parseInt(matchParc[2], 10) : 1;
    const inicioParc = matchParc ? parseInt(matchParc[1], 10) : 1;

    if (totalParc > 1 && form.vencimento) {
      // Gera entradas restantes a partir da parcela "inicioParc"
      const novos = [];
      const baseDate = new Date(form.vencimento);
      const grupoId = uid(); // pra agrupar todas as parcelas como um conjunto
      for (let i = inicioParc; i <= totalParc; i++) {
        const offset = i - inicioParc; // 1ª gerada usa o vencimento do form
        const venc = new Date(baseDate);
        venc.setMonth(venc.getMonth() + offset);
        const vencISO = venc.toISOString().slice(0, 10);
        novos.push({
          ...data,
          id: uid(),
          parcela: `${i}/${totalParc}`,
          vencimento: vencISO,
          grupoParcelamento: grupoId,
          ...(form.tipo === "receber" ? { recebido: false } : { pago: false }),
        });
      }
      if (form.tipo === "receber") setDevedores([...devedores, ...novos]);
      else setDividas([...dividas, ...novos]);
      toast.success(`${novos.length} parcela${novos.length > 1 ? "s" : ""} de "${form.nome}" cadastrada${novos.length > 1 ? "s" : ""} (até ${totalParc}/${totalParc}).`);
      setForm(null);
      return;
    }

    // Sem parcelamento: cria uma entrada única
    if (form.tipo === "receber") {
      setDevedores([...devedores, { ...data, id: uid(), recebido: false }]);
    } else {
      setDividas([...dividas, { ...data, id: uid(), pago: false }]);
    }
    toast.success("Cadastrado.");
    setForm(null);
  };

  const excluir = async (item, tipo) => {
    const ok = await confirm({
      title: `Excluir "${item.nome}"?`,
      body: "A entrada será removida — você pode desfazer logo após.",
      danger: true, confirmLabel: "Excluir",
    });
    if (!ok) return;
    const backupDev = devedores;
    const backupDiv = dividas;
    if (tipo === "receber") setDevedores(devedores.filter(d => d.id !== item.id));
    else setDividas(dividas.filter(d => d.id !== item.id));
    toast.success(`"${item.nome}" excluído.`, {
      action: {
        label: "Desfazer",
        onClick: () => { setDevedores(backupDev); setDividas(backupDiv); },
      },
    });
  };

  /* ===== Baixa: cria transação + atualiza conta + marca como recebido/pago ===== */
  const confirmarBaixa = () => {
    if (!baixaForm.contaDestino) { toast.error("Selecione a conta."); return; }
    const conta = contas.find(c => c.nome === baixaForm.contaDestino);
    if (!conta) { toast.error("Conta não encontrada."); return; }

    const valor = parseFloat(baixaForm.valor) || 0;
    const isReceber = baixaForm.tipoOriginal === "receber";

    // 1) Cria transação
    const novaTransacao = {
      id: uid(),
      tipo: isReceber ? "receita" : "despesa",
      descricao: isReceber
        ? `Recebimento de ${baixaForm.nome}`
        : `Pagamento para ${baixaForm.nome}`,
      categoria: baixaForm.categoria || (isReceber ? "Outros" : "Outros"),
      conta: baixaForm.contaDestino,
      data: baixaForm.dataBaixa,
      valor,
      compensado: true,
      fixa: false,
      obs: baixaForm.obs || `Baixa automática${baixaForm.parcela ? ` (${baixaForm.parcela})` : ""}`,
    };
    setTransacoes([novaTransacao, ...transacoes]);

    // 2) Ajusta saldo da conta
    const delta = isReceber ? +valor : -valor;
    setContas(contas.map(c => c.id === conta.id ? { ...c, saldo: (parseFloat(c.saldo) || 0) + delta } : c));

    // 3) Marca como recebido/pago
    if (isReceber) {
      setDevedores(devedores.map(d => d.id === baixaForm.itemId ? { ...d, recebido: true, dataRecebimento: baixaForm.dataBaixa, contaRecebimento: baixaForm.contaDestino } : d));
    } else {
      setDividas(dividas.map(d => d.id === baixaForm.itemId ? { ...d, pago: true, dataPagamento: baixaForm.dataBaixa, contaPagamento: baixaForm.contaDestino } : d));
    }

    toast.success(
      isReceber
        ? `Recebido ${fmt(valor)} em ${baixaForm.contaDestino}. Saldo atualizado.`
        : `Pago ${fmt(valor)} de ${baixaForm.contaDestino}. Saldo atualizado.`
    );
    setBaixaForm(null);
  };

  /* ===== Render ===== */
  const devAbertos = devedores.filter(d => !d.recebido);
  const divAbertas = dividas.filter(d => !d.pago);

  // Mês corrente como tab default; tabs derivam de todos os vencimentos abertos
  const todosVencimentos = [...devAbertos, ...divAbertas]
    .map(d => d.vencimento)
    .filter(Boolean);
  const mesesDisponiveis = useMemo(() => {
    const set = new Set(todosVencimentos.map(v => v.slice(0, 7)));
    set.add(hoje.slice(0, 7));
    return [...set].sort();
  }, [todosVencimentos.join(","), hoje]);
  const [mesAtivo, setMesAtivo] = useState(""); // "" = Geral (todos os meses)
  const [vista, setVista] = useState("receber"); // "receber" | "pagar"

  const filtroMes = (item) => {
    if (!mesAtivo) return true;
    if (!item.vencimento) return mesAtivo === hoje.slice(0, 7); // sem data → cai no mês corrente
    return item.vencimento.slice(0, 7) === mesAtivo;
  };

  const receberMes = devAbertos.filter(filtroMes);
  const pagarMes   = divAbertas.filter(filtroMes);

  // Alertas globais (todos os meses)
  const totaisAlerta = {
    over: {
      receber: devAbertos.filter(d => d.vencimento && d.vencimento < hoje),
      pagar:   divAbertas.filter(d => d.vencimento && d.vencimento < hoje),
    },
    warn: {
      receber: devAbertos.filter(d => d.vencimento && d.vencimento >= hoje && d.vencimento <= em3dIso),
      pagar:   divAbertas.filter(d => d.vencimento && d.vencimento >= hoje && d.vencimento <= em3dIso),
    },
    ok: {
      receber: devAbertos.filter(d => d.vencimento && d.vencimento > em3dIso && d.vencimento <= fimMesIso),
      pagar:   divAbertas.filter(d => d.vencimento && d.vencimento > em3dIso && d.vencimento <= fimMesIso),
    },
  };

  const somaArr = (arr) => arr.reduce((s, d) => s + (parseFloat(d.valor) || 0), 0);

  // ===== Visão Geral · todos os meses =====
  const totalReceberAberto = somaArr(devAbertos);
  const totalPagarAberto   = somaArr(divAbertas);
  const saldoPrevisto      = totalReceberAberto - totalPagarAberto;

  // Recebido / pago no mês corrente (cruza com transações geradas via confirmarBaixa)
  const mesCorrenteISO = hoje.slice(0, 7);
  const baixadosNoMes = (transacoes || []).filter(t =>
    t.compensado && (t.data || "").startsWith(mesCorrenteISO) &&
    (t.descricao?.startsWith("Recebimento de") || t.descricao?.startsWith("Pagamento para"))
  );
  const recebidoNoMes = baixadosNoMes
    .filter(t => t.tipo === "receita")
    .reduce((s, t) => s + (parseFloat(t.valor) || 0), 0);
  const pagoNoMes = baixadosNoMes
    .filter(t => t.tipo === "despesa")
    .reduce((s, t) => s + (parseFloat(t.valor) || 0), 0);

  const totalOver = somaArr(totaisAlerta.over.receber) + somaArr(totaisAlerta.over.pagar);
  const totalWarn = somaArr(totaisAlerta.warn.receber) + somaArr(totaisAlerta.warn.pagar);
  const countOver = totaisAlerta.over.receber.length + totaisAlerta.over.pagar.length;
  const countWarn = totaisAlerta.warn.receber.length + totaisAlerta.warn.pagar.length;
  const countOk   = totaisAlerta.ok.receber.length   + totaisAlerta.ok.pagar.length;

  const mesLabel = (ym) => {
    if (!ym) return "—";
    const [y, m] = ym.split("-");
    const nomes = ["Jan","Fev","Mar","Abr","Mai","Jun","Jul","Ago","Set","Out","Nov","Dez"];
    return `${nomes[parseInt(m,10)-1]}/${y.slice(2)}`;
  };

  return (
    <div className="fade-up py-8 px-6">
      <PageHeader
        eyebrow="Finanças · Compromissos"
        title={<>A Receber & <em>Dívidas.</em></>}
        sub="Recebimentos futuros e dívidas a pagar. Na baixa, o dinheiro vai/sai da conta escolhida e vira transação automaticamente."
        action={
          <div className="flex gap-2 flex-wrap">
            <button className="btn-ghost" onClick={() => setForm({
              id: null, tipo: "receber", nome: "", valor: "", vencimento: "",
              categoria: "Outros", obs: "", parcela: "",
            })}>
              <Plus size={13} className="inline mr-1.5" /> Recebimento
            </button>
            <button className="btn-gold" onClick={() => setForm({
              id: null, tipo: "dividas", nome: "", valor: "", vencimento: "",
              categoria: "Outros", obs: "", parcela: "",
            })}>
              <Plus size={13} className="inline mr-1.5" /> Compromisso
            </button>
          </div>
        }
      />

      {/* ===== Visão geral · todos os meses ===== */}
      {(() => {
        const totalReceber = devAbertos.reduce((s, d) => s + (parseFloat(d.valor) || 0), 0);
        const totalPagar   = divAbertas.reduce((s, d) => s + (parseFloat(d.valor) || 0), 0);
        const saldoPrevisto = totalReceber - totalPagar;
        // Recebido/pago no mês corrente — soma das baixas (transações origemLoja: cheque-compensado / itens marcados)
        const ymAtual = hoje.slice(0, 7);
        const recebidoMes = devedores
          .filter(d => d.recebido && (d.dataRecebimento || "").startsWith(ymAtual))
          .reduce((s, d) => s + (parseFloat(d.valor) || 0), 0);
        const pagoMes = dividas
          .filter(d => d.pago && (d.dataPagamento || "").startsWith(ymAtual))
          .reduce((s, d) => s + (parseFloat(d.valor) || 0), 0);
        const baixasMes = recebidoMes + pagoMes;

        return (
          <div style={{
            border: `1px solid ${T.gold}66`,
            borderRadius: 10,
            padding: 10,
            marginBottom: 12,
            background: `linear-gradient(135deg, ${T.gold}08, transparent)`,
          }}>
            <div style={{
              fontSize: 9.5, letterSpacing: ".2em", textTransform: "uppercase",
              color: T.gold, fontWeight: 600, marginBottom: 12,
            }}>
              📊 Visão geral · todos os meses
            </div>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
              <VisaoCard label="Total a receber" valor={hidden ? null : totalReceber}
                         sub={`${devAbertos.length} aberto${devAbertos.length === 1 ? "" : "s"}`} cor={T.green} />
              <VisaoCard label="Total a pagar" valor={hidden ? null : totalPagar}
                         sub={`${divAbertas.length} aberto${divAbertas.length === 1 ? "" : "s"}`} cor={T.red} />
              <VisaoCard label="Saldo previsto" valor={hidden ? null : saldoPrevisto}
                         sub="receber − pagar" cor={saldoPrevisto >= 0 ? T.gold : T.red} />
              <VisaoCard label={`Baixas (${ymAtual})`} valor={hidden ? null : baixasMes}
                         sub={`recebido ${fmt(recebidoMes)} · pago ${fmt(pagoMes)}`} cor={T.muted} small />
            </div>
          </div>
        );
      })()}

      {/* Painel de alertas — Vermelho · Amarelo · Verde */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-2 mb-3">
        <AlertCard
          cor={T.red}
          titulo="Vencidos"
          count={countOver}
          valor={hidden ? null : totalOver}
          sub={`${totaisAlerta.over.receber.length} a receber · ${totaisAlerta.over.pagar.length} a pagar`}
          icone="🔴"
          actions={countOver > 0 ? [
            {
              label: "📱 Cobrar / Lembrar",
              title: "Disparar mensagens no WhatsApp para todos os itens vencidos",
              onClick: () => {
                const todos = [...totaisAlerta.over.receber, ...totaisAlerta.over.pagar];
                if (todos.length === 0) return;
                todos.forEach((item, i) => {
                  setTimeout(() => {
                    const isReceber = devAbertos.includes(item);
                    if (isReceber) whatsapp.cobrarDevedor(item);
                    else whatsapp.cobrarDivida(item);
                  }, i * 250);
                });
                toast.success(`Abrindo ${todos.length} conversa${todos.length > 1 ? "s" : ""} no WhatsApp.`);
              },
            },
            {
              label: "✓ Marcar pago / receber",
              title: "Abre o modal de baixa para o item vencido mais antigo",
              onClick: () => {
                const proximo = [...totaisAlerta.over.receber, ...totaisAlerta.over.pagar]
                  .sort((a, b) => (a.vencimento || "").localeCompare(b.vencimento || ""))[0];
                if (!proximo) return;
                const isReceber = devAbertos.includes(proximo);
                setBaixaForm({
                  itemId: proximo.id,
                  tipoOriginal: isReceber ? "receber" : "dividas",
                  nome: proximo.nome,
                  valor: proximo.valor,
                  categoria: proximo.categoria || "Outros",
                  obs: proximo.obs || "",
                  parcela: proximo.parcela || "",
                  contaDestino: contas[0]?.nome || "",
                  dataBaixa: hoje,
                });
              },
            },
          ] : null}
        />
        <AlertCard
          cor={T.gold}
          titulo="Vence em até 3 dias"
          count={countWarn}
          valor={hidden ? null : totalWarn}
          sub={`${totaisAlerta.warn.receber.length} a receber · ${totaisAlerta.warn.pagar.length} a pagar`}
          icone="🟡"
        />
        <AlertCard
          cor={T.green}
          titulo="No prazo (este mês)"
          count={countOk}
          valor={null}
          sub={`${totaisAlerta.ok.receber.length} a receber · ${totaisAlerta.ok.pagar.length} a pagar`}
          icone="🟢"
        />
      </div>

      {/* Tabs por mês */}
      <div style={{ display: "flex", gap: 4, marginBottom: 10, overflowX: "auto", paddingBottom: 3 }}>
        {(() => {
          const ativo = mesAtivo === "";
          const totalGeral = devAbertos.length + divAbertas.length;
          return (
            <button key="__geral" onClick={() => setMesAtivo("")}
              style={{
                padding: "5px 10px", fontSize: 10.5, letterSpacing: ".05em",
                background: ativo ? T.gold : T.bgSoft, color: ativo ? T.bg : T.muted,
                border: `1px solid ${ativo ? T.gold : T.border}`,
                borderRadius: 6, cursor: "pointer", fontWeight: ativo ? 700 : 500,
                whiteSpace: "nowrap", textTransform: "uppercase",
                display: "inline-flex", alignItems: "center", gap: 6,
              }}>
              📊 Geral
              {totalGeral > 0 && (
                <span style={{
                  fontSize: 9.5, padding: "1px 6px", borderRadius: 100,
                  background: ativo ? T.bg : T.border, color: ativo ? T.gold : T.muted, fontWeight: 600,
                }}>{totalGeral}</span>
              )}
            </button>
          );
        })()}
        {mesesDisponiveis.map(ym => {
          const ativo = ym === mesAtivo;
          const countNoMes =
            devAbertos.filter(d => d.vencimento && d.vencimento.slice(0,7) === ym).length +
            divAbertas.filter(d => d.vencimento && d.vencimento.slice(0,7) === ym).length;
          return (
            <button key={ym} onClick={() => setMesAtivo(ym)}
              style={{
                padding: "5px 10px", fontSize: 10.5, letterSpacing: ".05em",
                background: ativo ? T.gold : T.bgSoft, color: ativo ? T.bg : T.muted,
                border: `1px solid ${ativo ? T.gold : T.border}`,
                borderRadius: 6, cursor: "pointer", fontWeight: ativo ? 700 : 500,
                whiteSpace: "nowrap", textTransform: "uppercase",
                display: "inline-flex", alignItems: "center", gap: 6,
              }}>
              {mesLabel(ym)}
              {countNoMes > 0 && (
                <span style={{
                  fontSize: 9.5, padding: "1px 6px", borderRadius: 100,
                  background: ativo ? T.bg : T.border, color: ativo ? T.gold : T.muted, fontWeight: 600,
                }}>{countNoMes}</span>
              )}
            </button>
          );
        })}
      </div>

      {/* Toggle: A Receber | A Pagar */}
      <div style={{ display: "inline-flex", gap: 0, marginBottom: 12, background: T.bgSoft, padding: 3, borderRadius: 8, border: `1px solid ${T.border}` }}>
        {[
          { id: "receber", label: `💰 A Receber (${receberMes.length})`, cor: T.green },
          { id: "pagar",   label: `⚠️ A Pagar (${pagarMes.length})`,    cor: T.red   },
        ].map(t => {
          const ativo = vista === t.id;
          return (
            <button key={t.id} onClick={() => setVista(t.id)}
              style={{
                padding: "6px 14px", fontSize: 11.5, fontWeight: ativo ? 700 : 500,
                background: ativo ? T.card : "transparent",
                color: ativo ? t.cor : T.muted,
                border: ativo ? `1px solid ${t.cor}55` : `1px solid transparent`,
                borderRadius: 6, cursor: "pointer", letterSpacing: ".02em",
                whiteSpace: "nowrap",
              }}>
              {t.label}
            </button>
          );
        })}
      </div>

      {/* A Receber em CARDS, A Pagar em tabela */}
      <div style={{ display: "flex", flexDirection: "column", gap: 10 }}>
        {/* === A RECEBER · cards === */}
        {vista === "receber" && (
        <div style={{ background: T.card, border: `1px solid ${T.border}`, borderRadius: 10, overflow: "hidden" }}>
          <div style={{
            padding: "16px 18px", borderBottom: `1px solid ${T.border}`,
            display: "flex", alignItems: "center", justifyContent: "space-between", gap: 12, flexWrap: "wrap",
          }}>
            <div style={{ fontSize: 14, color: T.ink, fontWeight: 600 }}>
              💰 A Receber
              <span style={{ color: T.muted, fontWeight: 400, fontSize: 12, marginLeft: 6 }}>
                · {mesAtivo ? mesLabel(mesAtivo) : "Todos os meses"}
              </span>
              <span style={{ color: T.muted, fontWeight: 400, marginLeft: 8, fontSize: 11.5 }}>
                ({receberMes.length} {receberMes.length === 1 ? "item" : "itens"})
              </span>
            </div>
            <div className="num" style={{
              color: T.green, fontSize: 16, fontWeight: 600,
              fontFamily: T.serif, letterSpacing: "-.01em",
            }}>
              {hidden ? "•••" : fmt(receberMes.reduce((s, d) => s + (parseFloat(d.valor) || 0), 0))}
            </div>
          </div>

          {receberMes.length === 0 ? (
            <div style={{ padding: 30, textAlign: "center", color: T.muted, fontStyle: "italic", fontSize: 12.5 }}>
              Nada por aqui neste mês.
            </div>
          ) : (
            <div style={{ display: "flex", flexDirection: "column", gap: 8, padding: 12 }}>
              {receberMes.map(d => (
                <DevedorCard key={d.id} d={d} hidden={hidden} dueLabel={dueLabel}
                  onBaixa={() => setBaixaForm({
                    itemId: d.id, tipoOriginal: "receber",
                    nome: d.nome, valor: d.valor,
                    categoria: d.categoria || "Outros", obs: d.obs || "",
                    parcela: d.parcela || "",
                    contaDestino: contas[0]?.nome || "", dataBaixa: hoje,
                  })}
                  onEditar={() => setForm({ ...d, tipo: "receber" })}
                  onExcluir={() => excluir(d, "receber")}
                  onWhats={() => whatsapp.cobrarDevedor(d)}
                />
              ))}
            </div>
          )}
        </div>
        )}
        {vista === "pagar" && (
        <CompromissoTabela
          titulo="A Pagar"
          icone="⚠️"
          tipo="dividas"
          itens={pagarMes}
          corAccent={T.red}
          onBaixa={(item) => setBaixaForm({
            itemId: item.id, tipoOriginal: "dividas",
            nome: item.nome, valor: item.valor,
            categoria: item.categoria || "Outros", obs: item.obs || "",
            parcela: item.parcela || "",
            contaDestino: contas[0]?.nome || "", dataBaixa: hoje,
          })}
          onEditar={(item) => setForm({ ...item, tipo: "dividas" })}
          onExcluir={(item) => excluir(item, "dividas")}
          onWhats={(item) => whatsapp.cobrarDivida(item)}
          dueLabel={dueLabel}
          hidden={hidden}
          mesLabelTitulo={mesAtivo ? mesLabel(mesAtivo) : "Todos os meses"}
          showCredor
        />
        )}
      </div>

      {/* Modal Novo/Editar */}
      {form && (
        <Modal title={form.id ? "Editar" : `Novo ${form.tipo === "receber" ? "Recebimento" : "Compromisso"}`} onClose={() => setForm(null)}>
          <Field label={form.tipo === "receber" ? "Nome do devedor" : "Nome da dívida"} required>
            <input value={form.nome} onChange={e => setForm({ ...form, nome: e.target.value })}
                   placeholder={form.tipo === "receber" ? "Ex.: João Silva" : "Ex.: Aluguel · Apt 302"} />
          </Field>
          {form.tipo === "dividas" && (
            <Field label="Para quem está devendo (credor)" hint="Ex.: Imobiliária ABC, Banco Itaú, Mercado X">
              <input value={form.credor || ""} onChange={e => setForm({ ...form, credor: e.target.value })}
                     placeholder="Nome do credor" />
            </Field>
          )}
          {form.tipo === "receber" && (
            <Field label="Combinado" hint="Texto livre — ex.: Me pagar em 20/06, Dividido em 2x, Após receber salário">
              <input value={form.combinado || ""} onChange={e => setForm({ ...form, combinado: e.target.value })}
                     placeholder="O que foi combinado com o devedor" />
            </Field>
          )}
          <div className="grid grid-cols-2 gap-3">
            <Field label="Valor (R$)" required hint="Aceita 1500 · 1.500,00">
              <input type="text" inputMode="decimal" value={form.valor}
                     onChange={e => setForm({ ...form, valor: e.target.value })}
                     placeholder="1.500,00" />
            </Field>
            <Field label="Vencimento">
              <input type="date" value={form.vencimento}
                     onChange={e => setForm({ ...form, vencimento: e.target.value })} />
            </Field>
          </div>
          <div className="grid grid-cols-2 gap-3">
            <Field label="Categoria">
              <select value={form.categoria} onChange={e => setForm({ ...form, categoria: e.target.value })}>
                {categorias.filter(c => c.tipo === (form.tipo === "receber" ? "receita" : "despesa")).map(c => (
                  <option key={c.id} value={c.nome}>{c.nome}</option>
                ))}
                <option value="Outros">Outros</option>
              </select>
            </Field>
            <Field label="Parcela (opcional)" hint="Ex.: 1/3">
              <input value={form.parcela} onChange={e => setForm({ ...form, parcela: e.target.value })} placeholder="1/3" />
            </Field>
          </div>
          {form.tipo === "receber" && (
            <Field label="Combinado (opcional)" hint='Ex.: "Me pagar em 20/06", "Dividido em 2x"'>
              <input value={form.combinado || ""} onChange={e => setForm({ ...form, combinado: e.target.value })}
                     placeholder="Combinado de pagamento" />
            </Field>
          )}
          <Field label="Telefone (para WhatsApp)" hint="Opcional. Permite cobrar/avisar com 1 clique.">
            <input value={form.telefone || ""} onChange={e => setForm({ ...form, telefone: e.target.value })}
                   placeholder="(15) 99999-9999" />
          </Field>
          <Field label="Observações">
            <textarea value={form.obs} onChange={e => setForm({ ...form, obs: e.target.value })}
                      rows={2} placeholder="Detalhes, combinado…" />
          </Field>
          <div className="flex gap-3 justify-end mt-4">
            <button className="btn-ghost" onClick={() => setForm(null)}>Cancelar</button>
            <button className="btn-gold" onClick={save}>Salvar</button>
          </div>
        </Modal>
      )}

      {/* Modal Baixa */}
      {baixaForm && (() => {
        const conta = contas.find(c => c.nome === baixaForm.contaDestino);
        const valor = parseFloat(baixaForm.valor) || 0;
        const saldoAtual = parseFloat(conta?.saldo) || 0;
        const isReceber = baixaForm.tipoOriginal === "receber";
        const saldoFinal = saldoAtual + (isReceber ? valor : -valor);
        return (
          <Modal
            title={isReceber ? `Receber de ${baixaForm.nome}` : `Pagar para ${baixaForm.nome}`}
            onClose={() => setBaixaForm(null)}
          >
            <div style={{ padding: 12, background: T.bgSoft, borderRadius: 7, fontSize: 12.5, marginBottom: 18 }}>
              <div style={{ display: "flex", justifyContent: "space-between", color: T.muted }}>
                <span>Valor:</span>
                <span className="num" style={{ color: isReceber ? T.green : T.red, fontWeight: 600, fontSize: 16 }}>
                  {isReceber ? "+ " : "− "}{fmt(valor)}
                </span>
              </div>
              {baixaForm.parcela && (
                <div style={{ display: "flex", justifyContent: "space-between", marginTop: 4, fontSize: 11, color: T.faint }}>
                  <span>Parcela:</span><span>{baixaForm.parcela}</span>
                </div>
              )}
            </div>

            <Field label={isReceber ? "Receber em qual conta?" : "Pagar de qual conta?"} required>
              <select value={baixaForm.contaDestino}
                      onChange={e => setBaixaForm({ ...baixaForm, contaDestino: e.target.value })}>
                <option value="">Selecione…</option>
                {contas.map(c => (
                  <option key={c.id} value={c.nome}>
                    {c.nome} · saldo {fmt(c.saldo)}
                  </option>
                ))}
              </select>
            </Field>

            {conta && (
              <div style={{
                padding: 10, marginBottom: 12,
                background: `${isReceber ? T.green : T.red}11`,
                border: `1px solid ${isReceber ? T.green : T.red}33`,
                borderRadius: 6, fontSize: 11.5, color: T.muted,
              }}>
                Saldo {hidden ? "•••" : fmt(saldoAtual)} → <strong style={{ color: isReceber ? T.green : T.red }}>{hidden ? "•••" : fmt(saldoFinal)}</strong>
              </div>
            )}

            <div className="grid grid-cols-2 gap-3">
              <Field label="Data da baixa">
                <input type="date" value={baixaForm.dataBaixa}
                       onChange={e => setBaixaForm({ ...baixaForm, dataBaixa: e.target.value })} />
              </Field>
              <Field label="Categoria">
                <select value={baixaForm.categoria}
                        onChange={e => setBaixaForm({ ...baixaForm, categoria: e.target.value })}>
                  {categorias.filter(c => c.tipo === (isReceber ? "receita" : "despesa")).map(c => (
                    <option key={c.id} value={c.nome}>{c.nome}</option>
                  ))}
                  <option value="Outros">Outros</option>
                </select>
              </Field>
            </div>

            <div style={{
              padding: 10, marginTop: 12,
              background: `${T.green}11`, border: `1px solid ${T.green}33`,
              borderRadius: 6, fontSize: 11, color: T.green, lineHeight: 1.6,
            }}>
              ✓ Cria transação "{isReceber ? "Recebimento" : "Pagamento"} de {baixaForm.nome}" em {baixaForm.contaDestino || "—"}<br />
              ✓ {isReceber ? "Aumenta" : "Diminui"} saldo em {hidden ? "•••" : fmt(valor)}<br />
              ✓ Marca como {isReceber ? "recebido" : "pago"}
            </div>

            <div className="flex gap-3 justify-end mt-5">
              <button className="btn-ghost" onClick={() => setBaixaForm(null)}>Cancelar</button>
              <button
                style={{
                  background: isReceber ? T.green : T.red, color: isReceber ? T.bg : "#fff",
                  border: "none", padding: "10px 18px",
                  fontSize: 12, letterSpacing: ".1em", textTransform: "uppercase",
                  fontWeight: 600, cursor: "pointer", borderRadius: 7,
                }}
                onClick={confirmarBaixa}
              >
                {isReceber ? "✓ Confirmar recebimento" : "✓ Confirmar pagamento"}
              </button>
            </div>
          </Modal>
        );
      })()}
    </div>
  );
}

function VisaoCard({ label, valor, sub, cor, small }) {
  return (
    <div style={{
      padding: "9px 11px", background: T.card,
      border: `1px solid ${T.border}`, borderRadius: 7,
      borderLeft: `3px solid ${cor || T.border}`,
    }}>
      <div style={{
        fontSize: 8.5, letterSpacing: ".15em", textTransform: "uppercase",
        color: T.muted, marginBottom: 4, fontWeight: 600,
      }}>
        {label}
      </div>
      <div className="num" style={{
        fontFamily: T.serif, fontSize: small ? 13 : 15,
        color: cor || T.ink, fontWeight: 600, lineHeight: 1.1,
      }}>
        {valor == null ? "•••" : (typeof valor === "number" ? fmt(valor) : valor)}
      </div>
      <div style={{ fontSize: 9.5, color: T.faint, marginTop: 3 }}>{sub}</div>
    </div>
  );
}

function AlertCard({ cor, titulo, count, valor, sub, icone, actions }) {
  return (
    <div style={{
      background: T.card,
      border: `1px solid ${cor}55`,
      borderLeft: `3px solid ${cor}`,
      borderRadius: 8,
      padding: 10,
    }}>
      <div style={{ display: "flex", alignItems: "center", gap: 6, marginBottom: 4 }}>
        <span style={{ fontSize: 13 }}>{icone}</span>
        <div className="label-eyebrow" style={{ color: cor, fontSize: 9 }}>{titulo}</div>
      </div>
      <div className="num" style={{ fontSize: 17, fontWeight: 400, color: cor, lineHeight: 1.1 }}>
        {count} {count === 1 ? "item" : "itens"}
      </div>
      {valor != null && (
        <div className="num" style={{ fontSize: 11, color: T.muted, marginTop: 2 }}>
          {fmt(valor)}
        </div>
      )}
      <div style={{ fontSize: 10, color: T.faint, marginTop: 4 }}>{sub}</div>
      {actions && actions.length > 0 && (
        <div style={{ display: "flex", flexWrap: "wrap", gap: 6, marginTop: 12, paddingTop: 10, borderTop: `1px dashed ${cor}33` }}>
          {actions.map(a => (
            <button key={a.label} onClick={a.onClick} title={a.title}
              style={{
                background: `${cor}22`, color: cor,
                border: `1px solid ${cor}55`, borderRadius: 6,
                padding: "5px 10px", fontSize: 10.5, fontWeight: 600,
                letterSpacing: ".05em", cursor: "pointer", whiteSpace: "nowrap",
              }}>
              {a.label}
            </button>
          ))}
        </div>
      )}
    </div>
  );
}

function CompromissoTabela({
  titulo, icone, tipo, itens, corAccent,
  onBaixa, onEditar, onExcluir, onWhats,
  dueLabel, hidden, mesLabelTitulo, showCredor,
}) {
  const isReceber = tipo === "receber";
  const total = itens.reduce((s, d) => s + (parseFloat(d.valor) || 0), 0);
  const labelAcao = isReceber ? "Receber" : "Pagar";

  return (
    <div style={{ background: T.card, border: `1px solid ${T.border}`, borderRadius: 10, overflow: "hidden" }}>
      <div style={{
        padding: "10px 14px", borderBottom: `1px solid ${T.border}`,
        display: "flex", alignItems: "center", justifyContent: "space-between", gap: 10, flexWrap: "wrap",
      }}>
        <div>
          <div style={{ fontSize: 14, color: T.ink, fontWeight: 600, letterSpacing: ".02em" }}>
            {icone} {titulo}
            {mesLabelTitulo && (
              <span style={{ color: T.muted, fontWeight: 400, fontSize: 12, marginLeft: 6 }}>
                · {mesLabelTitulo}
              </span>
            )}
            <span style={{ color: T.muted, fontWeight: 400, marginLeft: 8, fontSize: 11.5 }}>
              ({itens.length} {itens.length === 1 ? "item" : "itens"})
            </span>
          </div>
        </div>
        <div className="num" style={{
          color: corAccent, fontSize: 16, fontWeight: 600,
          fontFamily: T.serif, letterSpacing: "-.01em",
        }}>
          {hidden ? "•••" : fmt(total)}
        </div>
      </div>

      {itens.length === 0 ? (
        <div style={{ padding: 30, textAlign: "center", color: T.muted, fontStyle: "italic", fontSize: 12.5 }}>
          Nada por aqui neste mês.
        </div>
      ) : (
        <div style={{ overflowX: "auto" }}>
          <table className="tbl" style={{ width: "100%", borderCollapse: "collapse", fontSize: 12.5 }}>
            <thead>
              <tr>
                <ThSmall>Vence</ThSmall>
                <ThSmall>Nome</ThSmall>
                {showCredor && <ThSmall>Credor</ThSmall>}
                <ThSmall>Obs</ThSmall>
                <ThSmall align="right">Valor</ThSmall>
                <ThSmall align="right">Ações</ThSmall>
              </tr>
            </thead>
            <tbody>
              {itens.map(item => {
                const due = dueLabel(item.vencimento);
                const isOver = due.status === "over";
                const isWarn = due.status === "warn";
                const rowBg = isOver ? `${T.red}1a`
                            : isWarn ? `${T.gold}1a`
                            : "transparent";
                return (
                  <tr key={item.id} style={{
                    background: rowBg,
                    borderTop: `1px solid ${T.border}`,
                  }}>
                    <td style={{ ...tdMini, whiteSpace: "nowrap" }}>
                      {item.vencimento ? (
                        <div>
                          <div style={{ color: due.cor, fontWeight: (isOver || isWarn) ? 600 : 400, fontSize: 12.5 }}>
                            {item.vencimento.slice(8,10)}/{item.vencimento.slice(5,7)}/{item.vencimento.slice(2,4)}
                          </div>
                          <div style={{ fontSize: 10, color: T.muted, marginTop: 2 }}>
                            {(() => {
                              const d = new Date(item.vencimento);
                              const h = new Date(new Date().toISOString().slice(0,10));
                              const dias = Math.round((d - h) / 86400000);
                              if (dias < 0) return `há ${-dias}d`;
                              if (dias === 0) return "hoje";
                              return `em ${dias}d`;
                            })()}
                          </div>
                        </div>
                      ) : "—"}
                    </td>
                    <td style={{ ...tdMini, color: T.ink }}>
                      <div style={{ display: "flex", alignItems: "center", gap: 6 }}>
                        <span>{item.nome}</span>
                        {item.parcela && (
                          <span style={{ fontSize: 10, color: T.faint, fontStyle: "italic" }}>· {item.parcela}</span>
                        )}
                      </div>
                    </td>
                    {showCredor && (
                      <td style={{ ...tdMini, color: T.muted, fontSize: 12 }}>
                        {item.credor || <span style={{ color: T.faint }}>—</span>}
                      </td>
                    )}
                    <td style={{ ...tdMini, color: T.muted, fontSize: 11, maxWidth: 160, overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}
                        title={item.obs || ""}>
                      {item.obs || "—"}
                    </td>
                    <td className="num" style={{ ...tdMini, textAlign: "right", color: corAccent, fontWeight: 500, whiteSpace: "nowrap" }}>
                      {hidden ? "•••" : fmt(item.valor)}
                    </td>
                    <td style={{ ...tdMini, textAlign: "right", whiteSpace: "nowrap" }}>
                      <button onClick={() => onBaixa(item)}
                              title={`✓ ${labelAcao}`}
                              style={{
                                background: corAccent, color: isReceber ? T.bg : "#fff",
                                border: "none", padding: "6px 12px",
                                fontSize: 10.5, letterSpacing: ".08em", textTransform: "uppercase",
                                fontWeight: 600, cursor: "pointer", borderRadius: 5,
                                marginRight: 4, display: "inline-flex", alignItems: "center", gap: 4,
                              }}>
                        <Check size={11} /> {labelAcao}
                      </button>
                      <button onClick={() => onWhats(item)}
                              title="WhatsApp"
                              style={{ ...miniIconBtn, color: "#25D366" }}>
                        <MessageCircle size={12} />
                      </button>
                      <button onClick={() => onEditar(item)}
                              title="Editar"
                              style={{ ...miniIconBtn, color: T.muted }}>
                        <Edit3 size={12} />
                      </button>
                      <button onClick={() => onExcluir(item)}
                              title="Excluir"
                              style={{ ...miniIconBtn, color: T.red }}>
                        <Trash2 size={12} />
                      </button>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}

function ThSmall({ children, align }) {
  return (
    <th style={{
      padding: "8px 10px",
      textAlign: align || "left",
      fontSize: 9.5, letterSpacing: ".15em", textTransform: "uppercase",
      color: T.muted, fontWeight: 500,
      background: T.bgSoft,
      borderBottom: `1px solid ${T.border}`,
    }}>{children}</th>
  );
}

const tdMini = {
  padding: "8px 10px",
  verticalAlign: "middle",
};

const miniIconBtn = {
  background: "transparent",
  border: "none",
  cursor: "pointer",
  padding: 4,
  borderRadius: 5,
  marginLeft: 2,
};

// Hash determinístico do nome → gradient consistente (mesma pessoa = mesma cor)
function corDoNome(nome = "") {
  let h = 0;
  for (let i = 0; i < nome.length; i++) h = (h * 31 + nome.charCodeAt(i)) >>> 0;
  const hue1 = h % 360;
  const hue2 = (hue1 + 40) % 360;
  return `linear-gradient(135deg, hsl(${hue1}, 55%, 45%), hsl(${hue2}, 50%, 35%))`;
}

export function DevedorCard({ d, onBaixa, onWhats, onEditar, onExcluir, hidden, dueLabel }) {
  const due = dueLabel ? dueLabel(d.vencimento) : null;
  const isOver = due?.status === "over";
  const isWarn = due?.status === "warn";
  const inicial = (d.nome || "?").trim().charAt(0).toUpperCase();
  const borderL = isOver ? `3px solid ${T.red}` : isWarn ? `3px solid ${T.gold}` : `1px solid ${T.border}`;
  return (
    <div style={{
      display: "flex", alignItems: "center", gap: 10,
      padding: "8px 11px",
      background: T.card,
      border: `1px solid ${T.border}`,
      borderLeft: borderL,
      borderRadius: 7,
      flexWrap: "wrap",
    }}>
      <div style={{
        width: 30, height: 30, borderRadius: "50%",
        background: corDoNome(d.nome || "?"),
        color: "#fff", display: "grid", placeItems: "center",
        fontWeight: 700, fontSize: 12, flexShrink: 0,
      }}>{inicial}</div>

      <div style={{ flex: 1, minWidth: 160 }}>
        <div style={{ color: T.ink, fontSize: 12.5, fontWeight: 600, display: "flex", alignItems: "center", gap: 5 }}>
          {d.nome}
          {isOver && (
            <span style={{
              fontSize: 8.5, padding: "1px 5px", borderRadius: 100,
              background: `${T.red}22`, color: T.red, letterSpacing: ".08em",
              textTransform: "uppercase", fontWeight: 700,
            }}>Vencido</span>
          )}
          {isWarn && (
            <span style={{
              fontSize: 8.5, padding: "1px 5px", borderRadius: 100,
              background: `${T.gold}22`, color: T.gold, letterSpacing: ".08em",
              textTransform: "uppercase", fontWeight: 700,
            }}>Em 3 dias</span>
          )}
        </div>
        {(d.obs || d.criadoEm || d.dataEmprestimo) && (
          <div style={{ fontSize: 10, color: T.muted, marginTop: 1 }}>
            {d.obs || ""}{d.obs && (d.criadoEm || d.dataEmprestimo) && " · "}
            {d.dataEmprestimo || d.criadoEm || ""}
          </div>
        )}
      </div>

      <div style={{ minWidth: 100, textAlign: "right" }}>
        <div className="num" style={{ color: T.green, fontFamily: T.serif, fontSize: 14, fontWeight: 600 }}>
          {hidden ? "•••" : fmt(d.valor)}
        </div>
        {d.combinado && (
          <div style={{ fontSize: 9.5, color: T.muted, fontStyle: "italic", marginTop: 1 }}>
            {d.combinado}
          </div>
        )}
        {due && d.vencimento && !d.combinado && (
          <div style={{ fontSize: 9.5, color: due.cor, marginTop: 1 }}>
            {due.txt}
          </div>
        )}
      </div>

      <div style={{ display: "inline-flex", gap: 4, flexShrink: 0 }}>
        <button onClick={() => onBaixa(d)} title="✓ Receber"
          style={{ background: "transparent", color: T.green, border: `1px solid ${T.green}55`,
                   padding: "5px 7px", borderRadius: 5, cursor: "pointer", display: "inline-flex", alignItems: "center" }}>
          <Check size={12} />
        </button>
        <button onClick={() => onWhats(d)} title="WhatsApp"
          style={{ background: "transparent", color: "#25D366", border: `1px solid #25D36655`,
                   padding: "5px 7px", borderRadius: 5, cursor: "pointer", display: "inline-flex", alignItems: "center" }}>
          <MessageCircle size={12} />
        </button>
        <button onClick={() => onEditar(d)} title="Editar"
          style={{ background: "transparent", color: T.muted, border: `1px solid ${T.border}`,
                   padding: "5px 7px", borderRadius: 5, cursor: "pointer", display: "inline-flex", alignItems: "center" }}>
          <Edit3 size={12} />
        </button>
        <button onClick={() => onExcluir(d)} title="Excluir"
          style={{ background: "transparent", color: T.red, border: `1px solid ${T.red}55`,
                   padding: "5px 7px", borderRadius: 5, cursor: "pointer", display: "inline-flex", alignItems: "center" }}>
          <Trash2 size={12} />
        </button>
      </div>
    </div>
  );
}
